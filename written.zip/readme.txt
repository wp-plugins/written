=== Written ===
Tags: plugin, content marketing, monetization, written, written.com, content, marketing, licensing
Contributors: written
Tested up to: 3.9.1
Requires at least: 3.5
Stable Tag: 2.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The best bloggers use Written to build authority and earn more for their top content.


== Description ==

Written values great content. We help brands build and target an audience for their products and services, and we help bloggers maximize the value and reach of their top content.  Our plugin allows bloggers to license their content to brands on the Written.com platform.

== Installation ==

1. Unzip the file you downloaded into your /wp-content/ directory

2. In your WordPress admin, click on "Plugins".

3. Activate the Written plugin.

4. Go to Written.com to create your blogger account

5. On the Written settings page of your WordPress admin, enter in your Written.com API key